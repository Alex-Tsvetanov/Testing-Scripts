#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;






int main() {
while(true){cout<<"This work"<<" ";}

}






