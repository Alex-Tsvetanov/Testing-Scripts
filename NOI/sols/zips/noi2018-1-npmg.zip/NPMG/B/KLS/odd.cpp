#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
using namespace std;
int main() {
while(true){cout<<"EZ GAME"<<" ";}
/*int n,izrazi,b,br;
int masiv[100000];
cin>>n;
while(n>=0){
        izrazi=getin
    izrazi=getch();

    if(izrazi>100000){cout<<"try again"<<endl;izrazi=getch();}
    else{masiv[br]=izrazi;}
    cout<<masiv[br]<<endl;







br++;
n--;
}

return (0);*/
}
