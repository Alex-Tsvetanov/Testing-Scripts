#include<iostream>
#include<cstring>
using namespace std;
int main (){
///long long ;
char cislaNaRed[1000],brCisla,pitaniq[1000],brCislaL,brCislaD,brPitaniq;
///brCisla=strlen(cislaNaRed);
///brPitaniq=strlen(pitaniq);
cin>>brCisla>>brPitaniq;
cout<<endl;
cin>>cislaNaRed[brCisla];
cout<<endl;
cin>>pitaniq[brPitaniq];





cout<<endl;
return 0;
}
