#include<iostream>
using namespace std;
int main(){
long long a,b,c,nula,edna,dve,tri,chetiri,pet,shest;
cin>>a>>b>>c;
tri=8;
edna=(a*b-((a-1)*2+(b-1)*2))*2+(a*c-(a*2+c*2))*4;
cout<<edna;
return 0;
}
