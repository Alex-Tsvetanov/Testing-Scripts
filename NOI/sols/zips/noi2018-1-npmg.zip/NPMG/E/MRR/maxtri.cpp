#include<iostream>
using namespace std;
int main ()
{
 long long a,b,c,chislo;
cin>>a>> b>> c ;
chislo=a*100+b*10+c;
cin>>chislo;




























  return 0;
}
