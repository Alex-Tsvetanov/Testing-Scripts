#include<iostream>
using namespace std;
int main ()
{
 long long n;
cin>>n;
{



}















if(n%3=0)
cin>>n/3>> 0;












 return 0;
}


