#include<iostream>
using namespace std;
int main(){
long long n,dvojni,trojni,x,y;
2<=n<=100;
n/(dvojni*x)==(trojni*y);
y>x;
cin>>n;
trojni*y>dvojni*x;










return 0;
}
