#include<iostream>
using namespace std;
int main(){

bool xyz,xzy,yzx,yxz,zyx,zxy;

long long x,y,z;
x; y; z==xyz;
x; z; y==xzy;
y; z; x==yzx;
y; x; z==yxz;
z; y; x==zyx;
z; x; y==zxy;

x;!0;


cin>>xyz;
if (xyz>xzy,yzx,yxz,zyx,zxy);

cin>>xzy;
if (xzy>xyz,yzx,yxz,zyx,zxy);

cin>>yzx;
if (yzx>xyz,xzy,yxz,zyx,zxy);

cin>>yxz;
if (yxz>xyz,xzy,yzx,zyx,zxy);

cin>>zyx;
if (zyx>xyz,xzy,yzx,yxz,zxy);

cin>>zxy;
if (zxy>xyz,xzy,yzx,yxz,zyx);



return 0;
}
