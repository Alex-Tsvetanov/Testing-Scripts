#include<iostream>
using namespace std;
int main(){
long long n,t,f,x,tx,tf,nx;
cin>>n;
cin>>t;
cin>>f;
cin>>x;
5<=n<=100;
1<=f<n;
2<=t<=24;
10<=x<=60;
tf==1;
tx==t-tf;
nx==n-f;















return 0;
}
