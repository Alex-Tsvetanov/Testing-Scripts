#include<iostream>
using namespace std;
int main() {
long long f,t,n,x;
cout<<"t ";cin>>t;cout<<"f ";cin>>f;cout<<"x ";cin>>x;cout<<"n ";cin>>n;
if
return 0;
}
