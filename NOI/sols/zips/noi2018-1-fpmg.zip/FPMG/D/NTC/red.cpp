#include <iostream>
using namespace std;

int main(){
int N,K;
 int masiw[ N];
  }
