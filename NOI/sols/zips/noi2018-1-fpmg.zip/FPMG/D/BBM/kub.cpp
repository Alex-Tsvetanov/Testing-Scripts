#include<iostream>
using namespace std;
int main(){
long long A,B,C;
long long kubcheta=0;
long long BBSK=0;
long long malkikuboveotA=0;
long long malkikuboveotB=0;
long long malkikuboveotC=0;
cin>>A>>B>>C;
BBSK=0;
malkikuboveotA=A*2;
malkikuboveotB=B*4;
malkikuboveotC=C*2;
cout<<BBSK<<" "<<malkikuboveotA<<" "<<malkikuboveotB<<" "<<malkikuboveotC<<" "<<BBSK<<" "<<BBSK<<" "<<BBSK;
while(A>1000){
    cout<<"n";
}
while(B>1000){
    cout<<"n";
}
while(C>1000){
    cout<<"n";
}
return 0;
}
