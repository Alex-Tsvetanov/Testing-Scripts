#include<iostream>
using namespace std;
int main(){
    cout<<"**************************************************************************************"<<endl;
cout<<"v shkolata na koqto hodq na c++ ne sme uchili masvi zashtoto hodq na neq samo ot 1 mesec"<<endl;
    cout<<"**************************************************************************************"<<endl;
return 0;
}
