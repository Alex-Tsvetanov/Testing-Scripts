#include<iostream>
using namespace std;
int main(){
long long Abakteriq,Bbakteriq,Cbakteriq,Dbakteriq,Kden;
long long broibakt=0;
cin>>Abakteriq>>Bbakteriq>>Cbakteriq>>Dbakteriq>>Kden;
broibakt=Dbakteriq;
for(Kden=0;Kden<10;Kden++){
if(Kden>10){
    cout<<"sdfgh";
}
}
for(Dbakteriq=0;Dbakteriq<1000;Dbakteriq++){
for(Abakteriq=0;Abakteriq<Dbakteriq;Abakteriq++){
    if(Abakteriq>Dbakteriq){
        cout<<"aaaaa";
    }
}
}
cout<<"*******************"<<endl;
cout<<broibakt;
return 0;
}
