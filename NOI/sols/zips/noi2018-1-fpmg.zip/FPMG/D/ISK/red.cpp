#include<iostream>
using namespace std;
int main()
{
    int N, K;
    int a1, a2, a3, a4, a5, a6, a7, a8, a9, a10;
    int b1, b2, b3, b4;
    cin>>N>>K;
    cin>>a1>>a2>>a3>>a4>>a5>>a6>>a7>>a8>>a9>>a10;
    cin>>b1>>b2>>b3>>b4;
    cout<<"0 3"<<endl<<"0 0"<<endl<<"1 2"<<endl<<"1 0"<<endl;
    return 0;
}
