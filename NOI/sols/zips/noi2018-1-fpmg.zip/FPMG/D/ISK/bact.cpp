#include<iostream>
using namespace std;

int BR;

int K;

int funkciq(int A)
{
    A>=0;
    int B, B2, C, D;
    D<=1000;
    A<=D;
    K>=1;
    K<=1000000000000000000;
    cin>>A>>B>>C>>D>>K;
    B2=A*B;
    if(B2>C)
    {
       BR=D;
    }
    else
    {
        BR=0;
    }

}
int main()
{
    funkciq(K);

    cout<<BR;
    return 0;
}

