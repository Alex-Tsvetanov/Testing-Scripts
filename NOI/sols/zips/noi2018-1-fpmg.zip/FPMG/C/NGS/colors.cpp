#include <iostream>
using namespace std;

int main()
{
    long long N, K, balloons[25010];
    cin >> N >> K;
    for(long long i = 1; i <= N; i++)
    {
        cin >> balloons[i];
    }
    return 0;
}
