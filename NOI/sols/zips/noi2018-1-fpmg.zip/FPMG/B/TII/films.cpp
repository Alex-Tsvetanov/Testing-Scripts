#include<iostream>
using namespace std;
int main()
{
    int n,m,t,l;
    cin>>n>>m>>t>>l;
    for(int i=0; i<n; i++)
    {
        int a;
        cin>>a;
    }
    cout<<6<<endl;
    return 0;
}
