#include <iostream>
using namespace std;
int main (){
long n,t,f,x;
for(5<n;n>100;n=n+1){
  cout<<"Yes";
}
for(n=t;2<24>t;){
    cout<<"EXACT!";
}
for(;1<f<n;f=f+1){

}
for(;10<x<60;x=x+1){

}
for(;;){

    cout<<"NO";
}
return 0;
}
