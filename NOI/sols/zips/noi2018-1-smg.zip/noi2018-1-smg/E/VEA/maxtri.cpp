#include <iostream>
using namespace std;
int main (){
long long a,b,c,naigolamo,cifri;
cout<<"cifri=a,b,c";
for(;0>a,b,c<10;){
cout<<"naigolamo ==a>b>c";

}










return 0;
}
