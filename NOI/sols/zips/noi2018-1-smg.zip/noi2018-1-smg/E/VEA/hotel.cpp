#include <iostream>
using namespace std;
int main (){
long long n,ctai2,mesta,ctai3,v;
cout<<"broi stai s po 3 mesta";
cout<<"broi stai s po 2 mesta";
for(mesta=ctai2*2+ctai3*3;2<mesta>100;mesta=mesta+1){

cout<<"broi stai e";
}


return 0;
}
