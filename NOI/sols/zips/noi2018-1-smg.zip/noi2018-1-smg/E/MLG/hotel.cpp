#include<iostream>
using namespace std;
int main (){
long long n,stay;
cin>>n;
stay=n*5;
cout<<stay;
return 0;
}
