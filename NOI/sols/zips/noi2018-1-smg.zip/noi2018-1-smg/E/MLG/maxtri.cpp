#include<iostream>
using namespace std;
int main (){
long long a,b,c;
cin>>a>>b>>c;
if(a<b<c){
    cout<<abc;
    if(a<c<b){
        cout<<acb;
        if(c<a<b){
            cout<<cab;
            if(c<b<a){
                cout<<cba;
                if(b<a<c){
                    cout<<bac;
                    if(b<c<a){
                        cout<<bca;
                    }
                }
            }

        }
    }
}

return 0;
}
