#include<iostream>
using namespace std;
int main(){
long long x,y,z;
cin>>x>>y>>z;
cout<<z<<y<<x;
return 0;
}
