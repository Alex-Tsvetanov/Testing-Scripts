#include<iostream>
using namespace std;
int main(){
long long n,t,f,x,minutiZaReshenieNaOstanaliZadachi,chasoveZaOstanaliZadachi,chasoveVMinuti,ostavashtiMinutiDoKraq;
cin>>n>>t>>f>>x;
n>=5;
n<=100;
f>=1;
f<n;
t>=2;
t<=24;
x>=10;
x<=60;
ostavashtiMinutiDoKraq>=0;
    chasoveVMinuti=t*60;
(n-f)*x==minutiZaReshenieNaOstanaliZadachi;
    t-1==chasoveZaOstanaliZadachi;
    chasoveVMinuti-minutiZaReshenieNaOstanaliZadachi==ostavashtiMinutiDoKraq;
    cout<<"EXACT!"<<"\n";

return 0;
}
