#include<iostream>
using namespace std;
int main(){
long long n,dvoini,troini;
cin>>n;

if(n%2==0){
        n==dvoini*2;
    cout<<dvoini<<" "<<0;
}else{
    n==dvoini*2-troini;
cout<<dvoini<<" "<<1;
}
return 0;
}
