#include <iostream>
using namespace std;
int main(){
long long n, brStPo3;
cin>>n;
bool namerihLiNa4in;
for(brStPo3=n/3;(n-3*brStPo3)%2!=0;brStPo3=brStPo3-1){
}
cout<<(n-brStPo3*3)/2<<" "<<brStPo3;
return 0;
}
