#include <iostream>
using namespace std;
int main(){
int n,a,t,b;
cout<<"Vuvedi broi sustezateli";
cin>>n;
while(n>100 or n<2){
	cout<<"Vuvedi pak broi sustezateli";
	cin>>n;
}
t==n%3;
if(t==0){
cout<<"Shte ima"<<n/3<<"stai";
}else
if (n%2==0&& t!=0){
	cout<<"Shte ima"<<n/2<<"stai";
}else
cout<<a<<" po dve ,"<<b<<" po tri stai";
return 0;
}
