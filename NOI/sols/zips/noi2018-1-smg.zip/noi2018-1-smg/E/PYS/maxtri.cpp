#include<iostream>
using namespace std;
int main(){
long long purvoch,vtoroch,tretoch;
cout<<"purvoto chislo e:"<<endl;
cin>>purvoch;
cout<<"vtoroto chislo e:"<<endl;
cin>>vtoroch;
cout<<"tretoto chislo e:"<<endl;
cin>>tretoch;
if(purvoch>vtoroch && purvoch>tretoch && vtoroch>tretoch)

return 0;
}
