#include<iostream>
using namespace std;
int main(){
long long NUchenizi;
long long dvoiniStai;
long long troiniStai;
cin>>NUchenizi;
NUchenizi<=100;
NUchenizi>=2;
for(dvoiniStai=0;dvoiniStai<NUchenizi/3;dvoiniStai=dvoiniStai+1){
}
    for(troiniStai=0;troiniStai<NUchenizi/2;troiniStai=troiniStai+1){
    }
cout<<dvoiniStai<<" "<<troiniStai;
return 0;
}
