#include <iostream>
"n"=50
if "n"*2*2+1*3=50+7
