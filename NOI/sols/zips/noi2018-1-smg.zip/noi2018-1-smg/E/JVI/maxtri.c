#include <iostream>
namespace std;
{
int main (1)
cout<<"123"
}
{
int main (2)
cout<<"213"
}
{
int main (3)
}cout<<"321"
