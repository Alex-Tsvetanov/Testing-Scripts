#include <iostream>
{
"n" = 12
"f" = 5
 "t" = 7
 "x" = 45
 if "n"<"t"
    cout<<"YES"
}
{
 if "n"="t"
    cout<<"EXACT"
}
{
if "n">"t"
       cout<<"NO"
}
