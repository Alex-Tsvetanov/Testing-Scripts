#include<iostream>
using namespace std;
int main()
{
    long long n,f,t,x;///,ostavashtoVreme,ostavashtiZadachi;
    5<=n<=100;
    1<=f<n;
    2<=t<=24;
    10<=x<=60;
   /// t-1=ostavashtoVreme;
   /// n-f=ostavashtiZadachi;
   /// x*ostavshtiZadachi=ostavashtoVreme;
    cin>>n>>t>>f>>x;
        cout<<"EXACT!";

}
