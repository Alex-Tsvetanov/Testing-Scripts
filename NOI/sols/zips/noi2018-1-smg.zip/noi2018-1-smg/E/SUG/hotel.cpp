#include<iostream>
using namespace std;
int main()
{
 long long n;
    cin>>n;
 for(n>=2;n<=100;n++){
      cout<<(n-2)/2;
        cout<< 1;
 }

 return 0;
}
