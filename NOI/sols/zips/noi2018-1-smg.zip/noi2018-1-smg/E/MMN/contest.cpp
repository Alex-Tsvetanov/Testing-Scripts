#include<iostream>
using namespace std;
int main ()
{
    long long n,t,f,x,r,i,o;
    t-1=r;
    n-f=i;
    i*x=o;
    cin>>n;
    cin>>t;
    cin>>f;
    cin>>x;
    if(n>=5 and n<=100 and f>=1 and f<n and t<=2 and t<=24 and x>=10 and x<=60 and r>o)
    cout<<"YES"<<endl;
    else if(n>=5 and n<=100 and f>=1 and f<n and t<=2 and t<=24 and x>=10 and x<=60 and r==o)
        cout<<"EXACT"<<endl;
    else if(n>=5 and n<=100 and f>=1 and f<n and t<=2 and t<=24 and x>=10 and x<=60 and r<o)
        cout<<"NO"<<endl;
}
