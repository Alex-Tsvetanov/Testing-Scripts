#include<iostream>
using namespace std;
int main(){




cout<<endl;
return 0;
}
