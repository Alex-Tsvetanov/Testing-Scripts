#include<iostream>
#include<string>
using namespace std;
int main(){
int n,izraz[100000];
cin>>n;
for(int i=0;i<n;i++){
        int j=0;
  while(izraz[j]!='\0'){
  cin>>izraz[j];
  izraz[j]++;
  }
}
int j=0;

return 0;
}
