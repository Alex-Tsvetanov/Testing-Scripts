#include<iostream>
using namespace std;
int main(){
long long A,B,C;
cin>>A;
cin>>B;
cin>>C;

















return 0;
}
