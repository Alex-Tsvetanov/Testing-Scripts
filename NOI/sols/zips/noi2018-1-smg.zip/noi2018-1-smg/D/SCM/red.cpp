#include<iostream>
using namespace std;
int main(){
long long a,i,k,m,brd,brl;
cin>>a;
cin>>i;
cin>>k;
brd=0;
brl=0;
m=i;
while(a<i){
        a=a+1;
        if(a=i){
            brl=brl+1;

        }




}
while(i<k){
        m=m+1;
    if(m=i){
        brd=brd+1;


    }




}


cout<<brl<<brd;









return 0;
}









