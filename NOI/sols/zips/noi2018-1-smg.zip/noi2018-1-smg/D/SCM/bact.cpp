#include<iostream>
using namespace std;
int main(){
long long A,B,C,D,K;

cin>>A>>B>>C>>D;

if(K>1){
if(A<D){
if(D<1000){
if(A,B,C>0){
A=A*B;
if(A<C){
    cout<<"0";



}
A=A-C;
if(A>D){
        A=D;



}

K=A;
cout<<K;

}


}
}
}
return 0;
}

