#include <iostream>
using namespace std;

int main(){
  long long A, B, C, D, K;
  cin>>A>>B>>C>>D>>K;

  if(B<C){
    cout<<'0';
    }
if(C<D){
cout<<D;
}

return 0;
}
