#include <iostream>
using namespace std;

int main(){
  long long chisl[broichisla],broichisla, zapitvaniq,nomerazapitani[zapitvaniq];
  cin>>broichisla>>zapitvaniq>>chisla[broichisla]>>nomerazapitani[zapitvaniq];










return 0;
}
