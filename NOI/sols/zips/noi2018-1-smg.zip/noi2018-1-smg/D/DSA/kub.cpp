#include<iostream>
using namespace std;
int main (){
    long long A,B,C;
    cin>>A>>B>>C;
    cout<<0<<" "<<A*2<<" "<<B*4<<" "<<C*2<<" "<<0<<" "<<0<<" "<<0;
    cout<<endl;
    return 0;
}
