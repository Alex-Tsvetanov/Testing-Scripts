#include<iostream>
using namespace std;
int main(){
    int a,b,c,po0,po1,po2;
    cin>>a>>b>>c;
    if(a<=2 || b<=2 || c<=2){
        po0=0;
    }
    cout<<po0<<" "<<po1<<" "<<po2<<" 8 0 0 0 ";
return 0;
}
