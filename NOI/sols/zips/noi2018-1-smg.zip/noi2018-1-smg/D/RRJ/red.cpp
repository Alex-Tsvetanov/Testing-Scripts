#include<iostream>
using namespace std;
int main(){
    int n,k,i=0,j=0,L,R;
    cin>>n>>k;
    int a[n],b[k];
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    for(j=0;j<k;j++){
        cin>>b[j];
        if(a[b[j]]==a[i]){

        }
    }

return 0;
}
