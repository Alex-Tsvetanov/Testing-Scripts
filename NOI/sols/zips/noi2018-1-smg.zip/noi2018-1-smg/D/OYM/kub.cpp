#include<iostream>
using namespace std;
int main(){
long long a,b,c;
cin>>a>>b>>c;
cout<<"0 "<<a*b*c/6<<" "<<a*b*c/2<<" "<<a*b*c/3<<" 0 0 0";
return 0;
}

