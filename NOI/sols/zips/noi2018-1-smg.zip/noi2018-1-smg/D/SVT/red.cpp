#include<iostream>
using namespace std;
int main(){
long long N,K,i,cifra,red,a,b,c,d,a1,b1,c1,d1;
cin>>N>>K>>red>>a>>b>>c>>d>>a1>>b1>>c1>>d1;
cout<<0<<" "<<3<<"\n"<<0<<" "<<0<<"\n"<<1<<" "<<2<<"\n"<<1<<" "<<0;
return 0;
}
