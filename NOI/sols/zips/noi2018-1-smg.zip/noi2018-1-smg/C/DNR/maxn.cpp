#include<iostream>

using namespace std;
int main(){
int n, numberOnPosition[16];
cin >> n;
for(int i = 0; i < n; i++) {
    cin >> numberOnPosition[i];
}
return 0;
}
