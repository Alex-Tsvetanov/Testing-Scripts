#include <iostream>
using namespace std;
int main()
{
long long n,p;
cin>>n>>p;
cout<<"1"<<endl;
cout<<p<<endl;
cout<<p+1<<endl;
cout<<p*p<<endl;
cout<<p*p+1<<endl;
cout<<p*(p+1)<<endl;
cout<<p*(p+1)+1<<endl;
cout<<n;
return 0;
}

