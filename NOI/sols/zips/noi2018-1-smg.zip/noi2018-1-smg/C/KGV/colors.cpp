#include <iostream>
using namespace std;
int main()
{
long long N,K,broibaloni[N];
cin>>N>>K;
cout<<endl;
cin>>broibaloni[N];
cout<<"1 1 2";




return 0;
}
