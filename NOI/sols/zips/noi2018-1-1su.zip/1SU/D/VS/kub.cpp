#include<iostream>
using namespace std;
int main;
long long A,B,C;
cin>>A>>B>>C:





return 0;
}
