#include<iostream>
using namespace std;
int main;{
long long A,B,C,D,K,ObshtoBakteriivMomenta;
cin>>A>>B>>C>>D>>K;

return 0;
}
