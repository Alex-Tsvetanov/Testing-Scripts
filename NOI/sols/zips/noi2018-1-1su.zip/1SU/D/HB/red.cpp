#include <iostream>
using namespace std;
int main(){
   long long n,k,i,a[k],k1;
   cin>>n>>k;
   for(k>=0;,k=k-1;){}
return 0;
}
