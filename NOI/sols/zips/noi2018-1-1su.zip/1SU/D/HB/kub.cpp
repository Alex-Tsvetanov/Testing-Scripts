#include <iostream>
using namespace std;
int main(){
    long long a,b,c,kubcheta1,kubcheta2,kubcheta3,kubcheta4,kubcheta5,kubcheta6,kubcheta0,lic1,lic2,lic3,lic4,lic5,lic6;
    cin>>a>>b>>c;
    kubcheta0=kubcheta1=kubcheta2=kubcheta3=kubcheta4=kubcheta5=kubcheta6=0;
    lic1=a*b;
    lic2=a*c;
    lic3=b*c;


    cout<<kubcheta0<<" "<<kubcheta1<<" "<<kubcheta2<<" "<<kubcheta3<<" "<<kubcheta4<<" "<<kubcheta5<<" "<<kubcheta6;
    return 0;
}
