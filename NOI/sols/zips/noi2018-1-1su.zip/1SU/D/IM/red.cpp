#include<iostream>
using namespace std;
int main()
{
int N,K,a=0,b=0,a1=0,b1=0,L,R;
cin>>N>>K;
while(a1<=N){
    a1=a1+1;
    cin>>a;
}
while(b1<=K){
    b1=b1+1;
    cin>>b;
}
return 0;
}
