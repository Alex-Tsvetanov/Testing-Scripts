#include<iostream>
using namespace std ;
int main (){
long long n,k;
cin>>n>>k;
for()

return 0 ;
}
