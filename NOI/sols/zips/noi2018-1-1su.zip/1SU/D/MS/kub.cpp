#include<iostream>
using namespace std ;
int main(){
long long a,b,c,ploshtParalelepiped,plosht1Kybche,brKubcheta;
cin>>a>>b>>c;
if(!(a & b & c >1000)){
 cout<<a+b+c*6=ploshtParalelepiped;
}
cout<<plosht1Kybche=1*6<<" "<<ploshtParalelepiped/plosht1Kybche=brKubcheta;



return 0 ;
}
