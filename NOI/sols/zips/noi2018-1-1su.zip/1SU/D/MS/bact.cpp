#include<iostream>
using namespace std ;
int main (){
long long A,B,C,D,K;
cin>>A>>B>>C>>D;
///KAKVO PRAVQ TYK
for(A>0;A<1000;A=A+1){
    for(B>0;B<1000;B=B+1){
       for(C>0;C<1000;C=C+1){
          for(D>0;D<1000;D=D+1){
            for(K>1;K<1000000000000000000;K=K+1){

            }
        }
    }
 }
}
return 0;
}
