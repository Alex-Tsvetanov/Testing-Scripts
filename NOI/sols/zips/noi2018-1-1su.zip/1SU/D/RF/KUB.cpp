#include<iostream>
using namespace std;
int main(){
long long a,b,c;
long long boqdisani steni;
cin>>a,b,c;
if(kupcheevedinkrai=3){
cout<<3boqdisanisteni;
if(kubche=1){
cout>>1;
      while(ima kupcheta=){
     }
 }
 }
return o;
}
