#include <iostream>
using namespace std;
int main (){
long long nBrZ;
long long tCasa;
long long fz;
long long xVr;
long long vreme;
cin>>n>>t>>fz>>x;
vreme=1;
for(fz=vreme;tCasa>vreme;nBrZ=xVr*nBrZ)

return 0;
}
