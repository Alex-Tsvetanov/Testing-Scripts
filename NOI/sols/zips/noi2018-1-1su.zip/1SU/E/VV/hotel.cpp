#include<iostream>
using namespace std;
int main()
{
    long long staipo2,staipo3,n;
    2<=n<=100;
    cin>>n;
    if(n%2==0){
cout<<"Shte trqbvat "<<n/2<< " stai za po 2 choveka";
    }else{
    if(n%3==0){
      cout<<"Shte trqbvat "<<n/3<< " stai za po 3 choveka";
    }
    }
    return 0;
}
