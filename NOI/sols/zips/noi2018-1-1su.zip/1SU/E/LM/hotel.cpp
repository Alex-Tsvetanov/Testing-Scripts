#include<iostream>
using namespace std;
int main () {
long long n,DvoiniStai=0,TroiniStai=0,i=n%3;
cin>>n;
for (n<101;n%3=0) {
    TroiniStai==n/3;
    DvoiniStai==0;
}
for (n<101;n%3>0){
    DvoiniStai==i/2;
    TroiniStai==n/3;
}
cout<<DvoiniStai;
cout<<TroiniStai;
return 0;
}
