#include<iostream>
using namespace std;
int main()
{
long long n,t,f,x,brZadachiPR,brZadachiGR,pomoshtna;
  cin>>n>>t>>f>>x;
    pomoshtna=f*60;
    if (pomoshtna)
    {

    }






return 0;
}



