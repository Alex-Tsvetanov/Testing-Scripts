#include <iostream>
using namespace std;
int main ()
{
    long long n,t,f,x;
    cin>>n>>t>>f>>x;
    5<=n<=100;
    1<=f<n;
    2<=t<=24;
    10<=x<=60;

    return 0;
}
