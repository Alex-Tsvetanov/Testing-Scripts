#include<iostream>
using namespace std;
int main () {
long long dvoini,troini,detsa;
cin>>detsa;
if(detsa/2==0) {
dvoini=detsa/2;
cout<<dvoini;
}else{
detsa/3==0;
troini=detsa/3;
cout<<troini;
cout<<" troini  ili   ";
}
if(detsa/3==0) {
troini=detsa/3;
cout<<troini;
}else{
detsa/2==0;
dvoini=detsa/2;
cout<<dvoini;
cout<<" dvoini";
}
if(detsa%3==2) {
troini=detsa%3;
cout<<troini;
detsa%2==71;
detsa/2==0;
cout<<dvoini-2;
cout<<" dvoini";
}

return 0;
}
