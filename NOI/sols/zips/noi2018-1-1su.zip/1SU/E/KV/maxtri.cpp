#include<iostream>
using namespace std;
int main () {
long long ng,nm,sr,golemina,a,b,c;
cin>>nm;
cin>>sr;
cin>>ng;
if(ng>sr>nm) {
if(ng>sr>nm) {
}else{
nm>sr>ng;
}
}else{
nm>sr>ng;
}
cout<<ng<<sr<<nm;
return 0;
}
