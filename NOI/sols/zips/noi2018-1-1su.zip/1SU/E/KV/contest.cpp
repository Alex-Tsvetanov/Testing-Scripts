#include<iostream>
using namespace std;
int main () {
long long n,t,f,x;
cin>>n;///zadachi
cin>>t;///vreme
cin>>f;///zadachi 1chas
cin>>x;///minuti za ost zadachi
5<=n<=100;
1<=f<n;
2<=t<=24;
10<=x<=60;
if(n==5<=n<=100) {
cout<<"NO";
}
if(n=5<=n<=100) {
cout<<"EXACT";
}else{
}else{
cout<<"EXACT";
}
cout<<"YES";
}
if(f==1<=f<n) {
cout<<"NO";
if(f=1<=f<n) {
cout<<"EXACT";

}else{
}else{
cout<<"EXACT";
cout<<"  ";
}
if(t==2<=t<=24) {
if(t=2<=t<=24) {
cout<<"EXACT";
}
cout<<"NO";
}else{
}else{
cout<<"EXACT";
cout<<"  ";
}
if(x==10<=x<=60) {
if(x=10<=x<=60) {
cout<<"EXACT`";
}
cout<<"NO";
}else{
else{
cout<<"EXACT";
cout<<"  ";
}





if(x=10<=x<=60) {
cout<<"EXACT`";
}else{
cout<<"EXACT";
}






return 0;

