#include<iostream>
using namespace std;
int main(){
long long n;
long long t;
long long f;
long long x;
cin>>n;
cin>>t;
cin>>f;
cin>>x;





return 0;
}
