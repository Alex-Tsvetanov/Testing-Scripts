#include<iostream>
using namespace std;
int main(){
long long nuchenici;
long long stai;
long long ostatak;
cin>>nuchenici;
if(nuchenici<100){
    stai=nuchenici/6+nuchenici/6;
    cout<<stai;
    cout<<nuchenici/2;
    cout<<nuchenici/3;
}
return 0;
}
